﻿
using System;

namespace _9zadań
{
    class Program

    {
        /*
123
4,21
1
2
3
4
5
6
7
8
9
10
1287863
189083908098197
word@press
999
p555ppp7www
25
46
23
10
10
11
36 
*
12
100
gadg12ASFAV31das2's;a]wfda'v.1 
         */
        static void Main(string[] args)
        {
            Console.WriteLine("<-- Zadanie 1 -->"); //123, 4,21 
            zadanie1.z1();
            Console.WriteLine("<-- Zadanie 1* -->");
            //    1
            //    2
            //    3
            //    4
            //    5
            //    6
            //    7
            //    8
            //    9
            //    10
            zadanie11.z2();
            Console.WriteLine("<-- Zadanie 2 -->"); //1287863
            zadanie2.z2();
            Console.WriteLine("<-- Zadanie 2* -->"); //189083908098197
            zadanie22.z22();
            Console.WriteLine("<-- Zadanie 3 -->"); //word@press
            zadanie33.z3();
            Console.WriteLine("<-- Zadanie 4 -->"); //999
            zadanie4.z4();
            Console.WriteLine("<-- Zadanie 5 -->"); //p555ppp7www
            zadanie5.z5();
            Console.WriteLine("<-- Zadanie 6 -->");
            zadanie6.z6();
            Console.WriteLine("<-- Zadanie 7 -->"); //25
            zadanie7.z7();
            Console.WriteLine("<-- Zadanie 8 -->"); //46 23
            zadanie8.z8();
            Console.WriteLine("<-- Zadanie 8* -->"); //10 10
            zadanie8plus.z8plus();
            Console.WriteLine("<-- Zadanie 9 -->"); //
            zadanie9.z9();
            Console.WriteLine("<-- Zadanie 10 -->"); //11
            zadanie10.z10();
            Console.WriteLine("<-- Zadanie 11 -->"); //36 * 12
            zadanienr11.z11();
            Console.WriteLine("<-- Zadanie 12 -->");//100
            zadanie12.z12();
            Console.WriteLine("<-- Zadanie 13 -->");//gadg12ASFAV31das2's;a]wfda'v.1
            zadanie13.z13();

        }
    }
}
