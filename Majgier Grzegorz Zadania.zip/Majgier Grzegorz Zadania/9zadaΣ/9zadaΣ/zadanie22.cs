﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _9zadań
{
    class zadanie22
    {
        public static void z22() {
            string x = Console.ReadLine();
            if(x.Contains("3"))
                Console.WriteLine($"{x} zawiera 3");
            else
                Console.WriteLine($"{x} nie zawiera 3");
    }
    } }
